
class IPinguino {
    // Método que permite al pingüino nadar
    void nadar() {  }
}