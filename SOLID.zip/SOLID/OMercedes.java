
class OMercedes extends Ocoche {
    // Implementación del método abstracto precioMedioCoche
    @Override
    int precioMedioCoche() { return 27000; }
}