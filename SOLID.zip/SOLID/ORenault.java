
class ORenault extends Ocoche {
    // Implementación del método abstracto precioMedioCoche
    @Override
    int precioMedioCoche() { return 18000; }
}