class LAudi extends Lcoche{
    // Implementación abstracto numAsientos
    @Override
    int numAsientos() {
        return 4;
    }
}