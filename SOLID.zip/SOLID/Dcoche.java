class Dcoche implements DVehiculo {
    // Implementación del método mover
    public void mover() {}
}