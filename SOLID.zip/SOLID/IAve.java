interface IAve {
    void volar();
    void comer();
}