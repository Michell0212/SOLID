abstract class Lcoche {
    
    abstract int numAsientos();
}