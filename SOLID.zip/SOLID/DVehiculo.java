interface DVehiculo {
    void mover();
}