
abstract class Ocoche {
    abstract int precioMedioCoche();
}