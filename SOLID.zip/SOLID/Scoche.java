// Clase Coche la marca del coche
class Scoche {
    
    String marca;

    // Constructor que inicializa el atributo marca
    Scoche(String marca){
        this.marca = marca;
    }

    // Método que devuelve marca
    String getMarcaCoche(){
        // Devuelvevalor atributo marca
        return marca;
    }
}