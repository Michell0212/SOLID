// Clase CocheDB  gestiona almacenamiento de coches
class ScocheDB {
    // Guarda un coche en la base de datos
    void guardarCocheDB(Scoche coche){}

    // Elimina un coche de la base de datos
    void eliminarCocheDB(Scoche coche){}
}